var readlineSync = require("readline-sync") ;

var userName = readlineSync.question("What's your Name ?? ");

var score = 0 ;

console.log(userName + " , Welcome to the game 'WEIRD_2020' !! ") ;
console.log("")
console.log("-----*-------*------*-----*------*-----") ;

// function 

function play(question , answer) {
  var userAnswer = readlineSync.question(question) ;

  if(userAnswer == answer){
    console.log("Woahhh.... You are Correct !!") ;
    score += 1 ;
  }else{
    console.log("Sorry , its wrong. Try next one :( ") ;
    score -= 1 ;
  }
  console.log("Your score is: "+ score) ;
  console.log("----------------------------") ;
  console.log("");
}

// array of objects
var Questions = [
  {
    question : "Which Team won the IPL in 2020 ? " , 
    answer: "MI"
  },
  {
    question : "The actor Pratik Gandhi played whose role in Scam 1992 ? " , 
    answer : "Harshad Mehata"
  },
  {
    question : "The name of MOST famous virus of 2020 [ in English ]" ,
    answer : "Covid" 
  },
  {
    question : "How many lockdowns get declared by India government ( in digit ) ?",
    answer : "4" 
  },
  {
    question : "In how many Unlockdowns India get restart ?" ,
    answer : "5" 
  },
  {
    question : "Name of the Cyclone which hit the wester coast of India.",
    answer : "Nisarga"
  },
  {
   question : "The country from where Covid-19 start spreading.",
   answer : "China"  
  }
] ;

// for loop to run FUNCTION 

for(var i=0 ; i<Questions.length ; i++ ){
  var currQuetion = Questions[i] ;
  play(currQuetion.question , currQuetion.answer) ;
}